/*	$Id: G3Encoder.h 2 2005-11-11 21:32:03Z faxguy $ */
/*
 * Copyright (c) 1994-1996 Sam Leffler
 * Copyright (c) 1994-1996 Silicon Graphics, Inc.
 * HylaFAX is a trademark of Silicon Graphics
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Sam Leffler and Silicon Graphics may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Sam Leffler and Silicon Graphics.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL SAM LEFFLER OR SILICON GRAPHICS BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */
#ifndef _G3Encoder_
#define _G3Encoder_
/*
 * Group 3 Facsimile Encoder Support.
 */
#include <stdint.h>

#include "Types.h"

class fxStackBuffer;
struct tableentry;

class G3Encoder {
private:
    bool	is2D;		// data is to be 1d/2d-encoded
    bool	isG4;		// data is to be G4-encoded
    bool	firstEOL;	// first EOL is not byte-aligned
    const u_char* bitmap;	// bit reversal table
    short	data;		// current input/output byte
    short	bit;		// current bit in input/output byte
    fxStackBuffer& buf;

    static const u_char zeroruns[256];
    static const u_char oneruns[256];

    static int findspan(const u_char**, int, int, const u_char*);
    static int find0span(const u_char*, int, int);
    static int find1span(const u_char*, int, int);
    static int finddiff(const u_char*, int, int, int);

    void	putBits(u_int bits, u_int length);
    void	putcode(const tableentry& te);
    void	putspan(int span, const tableentry* tab);
    void	flushBits();
public:
    G3Encoder(fxStackBuffer&);
    virtual ~G3Encoder();

    void	setupEncoder(u_int fillOrder, bool, bool);
    void	encode(const void* raster, u_int w, u_int h, u_char* rp = NULL);
    void	encoderCleanup();
};
#endif /* _G3Encoder_ */
